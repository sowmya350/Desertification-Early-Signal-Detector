Desertification Early Signal Detector

Overview

This repository is a demo full-stack project for desertification early signal detection. It includes:
- FastAPI backend (backend/app) providing auth, prediction, and batch upload endpoints
- ML scripts (ml/) to generate demo data, train models, and save trained artifacts
- React frontend (frontend/) with a beautiful animated background, user auth, single-record input, and batch CSV upload
- Docker and docker-compose for local demo

Quickstart (local, development)

1. Create a Python virtual environment and install backend deps:
   cd backend
   python -m venv .venv
   .\.venv\Scripts\activate
   pip install -r requirements.txt

2. Generate demo data and train a model:
   cd ..\ml
   python generate_demo_data.py --out ../sample_data/demo_samples.csv
   python train_model.py --data ../sample_data/demo_samples.csv --out ../ml/artifacts

3. Run the backend:
   cd ../backend
   .\.venv\Scripts\activate
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

4. Run the frontend:
   cd ../frontend
   npm install
   npm start

Notes
- The project uses synthetic/demo data by default so the UI is responsive without large satellite downloads.
- For production, replace data generation with real datasets (MODIS/Sentinel/ERA5) and retrain models using ml/train_model.py.

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>
