import React, {useState} from 'react';
import axios from 'axios';

export default function PredictForm({setTheme}){
  const [form, setForm] = useState({ndvi:0.35, precip:200, lst:26, eto:420, elevation:100});
  const [result, setResult] = useState(null);

  const onChange = (e)=> setForm({...form, [e.target.name]: parseFloat(e.target.value)});
  const submit = async ()=>{
    try{
      const token = localStorage.getItem('token');
      const headers = token ? {Authorization: `Bearer ${token}`} : {};
      const res = await axios.post('http://localhost:8000/predict', form, {headers});
      setResult(res.data);
      // choose background based on dryness
      const dryness = form.eto/(form.precip+1);
      if(dryness>3 || res.data.prob_10y>0.6){
        setTheme('dry');
      } else {
        setTheme('calm');
      }
    }catch(err){
      alert('Prediction failed: ' + (err.response?.data?.detail || err.message));
    }
  }

  return (
    <div className="panel">
      <div className="inputs">
        <label>NDVI<input name="ndvi" value={form.ndvi} onChange={onChange} step="0.01" /></label>
        <label>Precipitation (mm)<input name="precip" value={form.precip} onChange={onChange} step="1" /></label>
        <label>LST (°C)<input name="lst" value={form.lst} onChange={onChange} step="0.1" /></label>
        <label>ETo (mm)<input name="eto" value={form.eto} onChange={onChange} step="1" /></label>
        <label>Elevation (m)<input name="elevation" value={form.elevation} onChange={onChange} step="1" /></label>
        <button onClick={submit} className="predict-btn">Predict</button>
      </div>
      <div className="result">
        {result ? (
          <>
            <h3>Prediction</h3>
            <p>Estimated years until desertification: <b>{result.pred_years.toFixed(1)}</b></p>
            <p>Probability within 5y: {(result.prob_5y*100).toFixed(1)}%</p>
            <p>Probability within 10y: {(result.prob_10y*100).toFixed(1)}%</p>
            <p>Probability within 20y: {(result.prob_20y*100).toFixed(1)}%</p>
          </>
        ) : (
          <p>Enter values and click Predict to see results.</p>
        )}
      </div>
    </div>
  )
}
