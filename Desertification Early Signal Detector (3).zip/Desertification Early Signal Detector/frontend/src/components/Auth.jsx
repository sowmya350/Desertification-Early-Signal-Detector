import React, {useState} from 'react';
import axios from 'axios';

export default function Auth(){
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({username:'', password:''});

  const onChange = (e)=> setForm({...form, [e.target.name]: e.target.value});
  const submit = async ()=>{
    try{
      const url = mode==='login' ? 'http://localhost:8000/login' : 'http://localhost:8000/register';
      const res = await axios.post(url, form);
      if(mode==='login'){
        localStorage.setItem('token', res.data.access_token);
        alert('Logged in');
      } else {
        alert('Registered, please login');
        setMode('login');
      }
    }catch(err){
      alert('Auth error: ' + (err.response?.data?.detail || err.message));
    }
  }

  return (
    <div className="auth">
      <div className="auth-toggle">
        <button onClick={()=>setMode('login')} disabled={mode==='login'}>Login</button>
        <button onClick={()=>setMode('register')} disabled={mode==='register'}>Register</button>
      </div>
      <div className="auth-form">
        <input name="username" placeholder="username" value={form.username} onChange={onChange} />
        <input name="password" type="password" placeholder="password" value={form.password} onChange={onChange} />
        <button onClick={submit}>{mode==='login' ? 'Login' : 'Register'}</button>
      </div>
    </div>
  )
}
