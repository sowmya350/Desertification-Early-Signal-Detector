import React, {useState} from 'react';
import PredictForm from './components/PredictForm';
import Auth from './components/Auth';

export default function App(){
  const [theme, setTheme] = useState('calm');
  return (
    <div className={`app ${theme}`}>
      <header className="topbar">
        <h1>Desertification Early Signal Detector</h1>
        <div className="controls">
          <button onClick={()=>setTheme('calm')}>Calm (Rainy)</button>
          <button onClick={()=>setTheme('dry')}>Dry (Sunny)</button>
        </div>
        <div className="auth-controls">
          {/* login/register components mount here */}
        </div>
      </header>
      <div style={{position:'absolute', right:20, top:18}}>
        <Auth />
        <button onClick={()=>{localStorage.removeItem('token'); alert('Logged out')}} style={{marginLeft:8}}>Logout</button>
      </div>
      <main>
        <PredictForm setTheme={setTheme} />
      </main>
      <div className="animated-bg" aria-hidden="true"></div>
    </div>
  )
}
