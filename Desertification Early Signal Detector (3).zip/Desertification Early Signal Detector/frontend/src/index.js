import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import Auth from './components/Auth';

// make Auth globally available for header placement
window.Auth = Auth;
import './styles.css';

const root = createRoot(document.getElementById('root'));
root.render(<App />);
