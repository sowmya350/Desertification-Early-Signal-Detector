from fastapi import FastAPI, HTTPException, Depends, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import joblib
import pandas as pd
import os
import numpy as np
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
import sqlite3

# Simple settings (for demo only)
SECRET_KEY = "demo-secret-key-change-this"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60*24

pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")

app = FastAPI(title="Desertification Early Signal Detector")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'backend_users.db')
MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'ml', 'artifacts', 'model.pkl')
SCALER_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'ml', 'artifacts', 'scaler.pkl')

# Ensure DB exists
conn = sqlite3.connect(DB_PATH)
conn.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, hashed_password TEXT)''')
conn.commit()
conn.close()

class RegisterIn(BaseModel):
    username: str
    password: str

class LoginIn(BaseModel):
    username: str
    password: str

class PredictIn(BaseModel):
    # include key fields; frontend will send all recommended fields
    ndvi: float
    precip: float
    lst: float
    eto: float
    elevation: float = 0.0


def get_password_hash(password):
    return pwd_context.hash(password)


def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded


@app.post('/register')
def register(payload: RegisterIn):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    hashed = get_password_hash(payload.password)
    try:
        cur.execute('INSERT INTO users (username, hashed_password) VALUES (?,?)', (payload.username, hashed))
        conn.commit()
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))
    conn.close()
    return {"msg": "registered"}


@app.post('/login')
def login(payload: LoginIn):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT id, username, hashed_password FROM users WHERE username = ?', (payload.username,))
    row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=401, detail='Invalid credentials')
    user_id, username, hashed = row
    if not verify_password(payload.password, hashed):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    token = create_access_token({"sub": username})
    return {"access_token": token, "token_type": "bearer"}


def load_model():
    if os.path.exists(MODEL_PATH):
        try:
            model = joblib.load(MODEL_PATH)
            scaler = None
            if os.path.exists(SCALER_PATH):
                scaler = joblib.load(SCALER_PATH)
            return model, scaler
        except Exception:
            return None, None
    return None, None


def build_feature_vector(ndvi, precip, lst, eto, elevation, ndvi_slope=0.0):
    return [
        ndvi,
        precip,
        lst,
        eto,
        elevation,
        eto / (precip + 1),
        lst * eto,
        precip - eto,
        lst / (precip + 1),
        ndvi_slope,
    ]


@app.post('/predict')
async def predict(payload: PredictIn):
    model, scaler = load_model()
    features = build_feature_vector(
        payload.ndvi,
        payload.precip,
        payload.lst,
        payload.eto,
        payload.elevation,
    )
    arr = np.array(features).reshape(1, -1)
    if scaler is not None:
        try:
            # only apply scaler if feature count matches
            if getattr(scaler, 'n_features_in_', None) == arr.shape[1]:
                arr = scaler.transform(arr)
        except Exception:
            # skip scaling if incompatible
            pass
    if model is not None:
        try:
            if getattr(model, 'n_features_in_', None) == arr.shape[1]:
                pred_years = float(model.predict(arr)[0])
            else:
                # model incompatible with incoming feature vector; use fallback
                raise ValueError('Model expects different feature count')
        except Exception:
            ndvi, p, t, e, elev = features[:5]
            dryness_index = e / (p + 1)
            pred_years = max(0.0, 30.0 - (dryness_index * 10.0) - (ndvi * 40.0))
        # derive horizon probabilities
        prob_5 = float(np.clip(1 - pred_years / 10.0, 0.0, 1.0))
        prob_10 = float(np.clip(1 - pred_years / 20.0, 0.0, 1.0))
        prob_20 = float(np.clip(1 - pred_years / 50.0, 0.0, 1.0))
    else:
        # fallback heuristic
        ndvi, p, t, e, elev = features[:5]
        dryness_index = e / (p + 1)
        pred_years = max(0.0, 30.0 - (dryness_index * 10.0) - (ndvi * 40.0))
        prob_5 = float(np.clip(1 - pred_years / 10.0, 0.0, 1.0))
        prob_10 = float(np.clip(1 - pred_years / 20.0, 0.0, 1.0))
        prob_20 = float(np.clip(1 - pred_years / 50.0, 0.0, 1.0))

    return {
        "pred_years": pred_years,
        "prob_5y": prob_5,
        "prob_10y": prob_10,
        "prob_20y": prob_20,
        "model_loaded": model is not None
    }


@app.post('/predict/batch')
async def predict_batch(file: UploadFile = File(...)):
    contents = await file.read()
    import io
    df = pd.read_csv(io.BytesIO(contents))
    required = ['ndvi','precip','lst','eto','elevation']
    for c in required:
        if c not in df.columns:
            raise HTTPException(status_code=400, detail=f"Missing column {c}")
    inputs = np.array([
        build_feature_vector(
            row.ndvi,
            row.precip,
            row.lst,
            row.eto,
            row.elevation,
            getattr(row, 'ndvi_slope', 0.0),
        )
        for row in df.itertuples(index=False)
    ])
    model, scaler = load_model()
    if scaler is not None:
        if getattr(scaler, 'n_features_in_', None) == inputs.shape[1]:
            inputs = scaler.transform(inputs)
    results = []
    for row in inputs:
        if model is not None:
            pred = float(model.predict(row.reshape(1,-1))[0])
        else:
            ndvi, p, lst, eto, elev = row[:5]
            di = eto/(p+1)
            pred = max(0.0, 30.0 - (di * 10.0) - (ndvi * 40.0))
        results.append(pred)
    df['pred_years'] = results
    return df.to_dict(orient='records')
